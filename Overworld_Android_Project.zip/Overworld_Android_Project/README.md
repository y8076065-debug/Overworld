# Overworld Android project

This wraps the supplied `Overworld.html` in an Android WebView and keeps its HTML/CSS/JavaScript bundled locally.

## Build an APK using GitHub Actions (phone-friendly workflow)
1. Create a new GitHub repository.
2. Upload the contents of this ZIP (the files inside `Overworld_Android_Project`, not the outer folder itself).
3. Open the repository's **Actions** tab and run **Build Overworld APK** (or push to `main`).
4. Open the completed workflow run, download the `Overworld-debug-apk` artifact, and extract `app-debug.apk`.
5. Transfer/install the APK on your Android phone. Android may ask you to allow installs from that browser/file manager.

## Notes
- The HTML file is bundled as `app/src/main/assets/index.html`.
- WebView DOM storage is enabled so the app can use `localStorage`.
- File selection is enabled for the farm-photo feature.
- This is a debug APK, suitable for personal testing. A release APK should be signed before public distribution.
- The supplied HTML itself says it does not connect to Minecraft live; the wrapper does not add that connection.
